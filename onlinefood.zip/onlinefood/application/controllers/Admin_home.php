<?php 
/**
 * 
 */
class Admin_home extends CI_Controller
{
     function index()
     {
     	$this->load->view('admin_home');
     }

     function product_insert_open()
     {
     	 $this->load->view('product_insert');
     }

     function product_disp_open()
     {
     	$this->load->model('Admin_model');
     $r1 = $this->Admin_model->select_data();
     	$this->load->view('disp_product',['d1'=>$r1]);
     }

     function ofline_order_open()
     {
     	 $this->load->view('ofline_order');
     }

     function ofline_order_disp_open()
     {
     	$this->load->model('Admin_model');
     	$res = $this->Admin_model->ofline_order_disp();
        $this->load->view('ofline_order_disp',['r1'=>$res]);
     }

     function online_order_disp_open()
     {
        $this->load->model('Admin_model');
        $res=$this->Admin_model->online_pro_disp();
        $this->load->view('online_order_disp',['res'=>$res]);
     }
     
     function product_insert()
     {
     	$data = $this->input->post();
     	$this->load->model('Admin_model');
     	unset($data['submit']);
     	$res = $this->Admin_model->insert_product($data);
        if($res)
        {
        	$this->load->view('product_insert',['msg'=>'insert']);
        }
        else
        {
        	$this->load->view('product_insert',['msg'=>'']);
        }
     }

     function p_search()
     {
     	$this->form_validation->set_rules('search','Product Name','required');
     	if ($this->form_validation->run()) 
     	{
     		$pname = $this->input->post('search');
            $this->load->model('Admin_model');
            $res = $this->Admin_model->sproduct($pname);
            if($res)
            {
            	$this->load->view('ofline_order',['d2'=>$res]);
            }
            else
            {
            	$this->load->view('ofline_order',['d2'=>'']);
            }
     		
     	}
     	else
     	{
     		echo form_validation();
     	}
     	
     }

    function pbok($id)
    {
    	$this->load->model('Admin_model');
    	$res = $this->Admin_model->pbook($id);
    	$this->load->view('pro_book',['r1'=>$res]);
    }

    function p_book2()
    {
    	$this->form_validation->set_rules('pname','Product Name','required');
    	$this->form_validation->set_rules('price','Price','required');
    	$this->form_validation->set_rules('name','Name','required');
    	$this->form_validation->set_rules('address','Address','required');
    	$this->form_validation->set_rules('city','City','required');
    	$this->form_validation->set_rules('pin','PIN Code','required');
    	$this->form_validation->set_rules('mno','Mobile Number','required');
    	$this->form_validation->set_rules('email','E-Mail','required');

    	if($this->form_validation->run())
    	{
            $pname = $this->input->post('pname');
            $price = $this->input->post('price');
            $name = $this->input->post('name');
            $address = $this->input->post('address');
            $city = $this->input->post('city');
            $pin = $this->input->post('pin');
            $mno = $this->input->post('mno');
            $email = $this->input->post('email');

            $data = array(
            	'cname'=>$name,
            	'address'=>$address,
            	'mobileno'=>$mno,
            	'pin'=>$pin,
            	'city'=>$city,
            	'email'=>$email,
            	'pname'=>$pname,
            	'price'=>$price,
            );

            $this->load->model('Admin_model');
            $res = $this->Admin_model->book2($data);
            if ($res) {
            	$this->load->view('book_res',['msg'=>'Booking Complet']);
            }
            else
            {
            	$this->load->view('book_res',['msg'=>'Sorry Try Again']);
            }
    	}
    	else
    	{
    		echo validation_errors();
    	}
    }

}


?>