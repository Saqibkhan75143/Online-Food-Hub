<?php
/**
 * 
 */
class Admin_login extends CI_Controller
{
	function index()
	{
		$this->load->view('admin_login');
	}

	function login()
	{
		$this->form_validation->set_rules('un','Username','required');
		$this->form_validation->set_rules('ps','Password','required');
		if ($this->form_validation->run()) {
			
			$un = $this->input->post('un');
			$ps = $this->input->post('ps');
			$this->load->model('Admin_loginn');
			$data = $this->Admin_loginn->login($un,$ps);
			if($data)
			{
				$this->session->set_userdata('uid',$un);
				return redirect('Admin_home');
			}
			else
			{
				echo "wrong User";
			}

		}
		else
		{
			$this->load->view('admin_login');
		}
	}
}


?>