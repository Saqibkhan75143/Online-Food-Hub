<?php 
/**
 * 
 */
class Home extends CI_Controller
{

	function index()
	{
		 $this->load->view('home');
	}

	function open_contect()
	{
		$this->load->view('contect');
	}

	function open_home()
	{
		$this->load->view('home');
	}

	function open_product()
	{
		$this->load->view('product');
	}

	function psc()
	{
       $data=$this->input->post('search');
	        $this->load->model('User_model');
	   $res=$this->User_model->ps($data);
		    $this->load->view('user_pro_disp',['res'=>$res]);
	}

	function b_now($id)
	{
		$this->load->model('User_model');
	  $resu = $this->User_model->ps1($id);
	    $this->load->view('user_pro_book',['res'=>$resu]);  
	}

	function book_final()
	{
		$data = $this->input->post();
         unset($data['sub']);
         $this->load->model('User_model');
        $r1 = $this->User_model->book_final($data);
        if($r1)
        {
           $this->load->view('book_success');
        }
	}
}

 
?>