<div class="row">
<div class="col-sm-4"><h1>Online Food HUB</h1></div>
	<div class="col-sm-8">
		<ul>
			<li><b><?= anchor('Home/open_home',"Home"); ?></b></li>
			<li><b><?= anchor('Home/open_product',"Product"); ?></b></li>
			<li><b><?= anchor('Home/open_contect',"Contect Us"); ?></b></li>
			<li><a href="#"><b>Login</b></a></li>
		</ul>
</div>	
</div>
