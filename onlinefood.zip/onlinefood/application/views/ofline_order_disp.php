<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE-edge" />
	<meta name="viewport" content="width=device-width" />
	<meta http-equiv="content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/style.css'); ?>">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
	<script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
</head>
<body>
<div class="container-fluid" style="background: darkred; color: white;">
    <?php include('admin_header.php'); ?>
	</div>
	<div class="container-fluid" id="banner"><br><br><br><br>
		<div class="col-sm-8" style="background: silver; margin-left: 20%;">
            <?php $un=$this->session->userdata('uid'); ?>
			<?php form_open('admin_login/login') ?>
			 <h1>Ofline Order Display</h1>
			 <table class="table">
			 	<tr>
			 		<td><font color="darkred"><b>Name</b></font></td>
			 		<td><font color="darkred"><b>Address</b></font></td>
			 		<td><font color="darkred"><b>City</b></font></td>
			 		<td><font color="darkred"><b>Pin Code</b></font></td>
			 		<td><font color="darkred"><b>Mobile No</b></font></td>
			 		<td><font color="darkred"><b>E-Mail</b></font></td>
			 		<td><font color="darkred"><b>Product Name</b></font></td>
			 		<td><font color="darkred"><b>Price</b></font></td>
			 	</tr>
			 	<?php 
			 	if (isset($r1)) {
			 		foreach ($r1 as $r2) {
			 		
			 	?>
			 	<tr>
			 		<td><center><?= $r2->cname; ?></center></td>
			 		<td><center><?= $r2->address; ?></center></td>
			 		<td><center><?= $r2->city; ?></center></td>
			 		<td><center><?= $r2->pin; ?></center></td>
			 		<td><center><?= $r2->mobileno; ?></center></td>
			 		<td><center><?= $r2->email; ?></center></td>
			 		<td><center><?= $r2->pname; ?></center></td>
			 		<td><center><?= $r2->price; ?></center></td>
			 	</tr>
			 	<?php } } ?>
			 </table>
		</div>
	</div>
	<div class="container-fluid" style="background: darkred; color: white;">
		<h2 align="center">Copyright@engineersworld.com</h2>
	</div>
</body>
</html>