<div class="row">
<div class="col-sm-4"><h1>Online Food HUB</h1></div>
	<div class="col-sm-8">
        <script type="text/javascript">
        	
        	$('document').ready(function(){
        		$('#p').click(function(){
        			$('#d2').hide();
        			$('#d1').slideToggle();
        		});

        		$('#o').click(function(){
        			$('#d1').hide();
        			$('#d2').slideToggle();
        		});

        	});

        </script>


		<ul>
			<li><b><?= anchor('Home/open_home',"Home"); ?></b></li>
			<li id="p"><b>Product</b>
            <div id="d1">
            	<p><?= anchor('Admin_home/product_insert_open','Product'); ?></p>
            	<p><?= anchor('Admin_home/product_disp_open','Product Display'); ?></p>
            </div>
			</li>
			<li id="o"><b>Order</b>
            <div id="d2">
            	<p><?= anchor('Admin_home/ofline_order_open','Ofline Order'); ?></p>
            	<p><?= anchor('Admin_home/ofline_order_disp_open','Ofline Order Display'); ?></p>
            	<p><?= anchor('Admin_home/online_order_disp_open','Online Order Display'); ?></p>
            </div>
			</li>
			<li><a href="#"><b>Login</b></a></li>
		</ul>
</div>	
</div>
