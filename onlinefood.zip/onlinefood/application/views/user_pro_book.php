<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE-edge" />
	<meta name="viewport" content="width=device-width" />
	<meta http-equiv="content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/style.css'); ?>">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
	<script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
</head>
<body>
<div class="container-fluid" style="background: darkred; color: white;">
    <?php include('user_header.php'); ?>
	</div>
	<div class="container-fluid" id="banner"><br><br><br><br>
		<div class="col-sm-6" style="background: silver; margin-left: 20%;">
			<h1>Product Book</h1>
			<?= form_open('home/book_final'); ?>
			<table class="table">
				<tr>
					<td><b>Product Name</b></td>
					<td><?= form_input(['name'=>'pname','value'=>$res->name,'placeholder'=>'Enter Name','class'=>'form-control']); ?></td>
					<td><b>Price</b></td>
					<td><?= form_input(['name'=>'price','value'=>$res->price,'class'=>'form-control']); ?>
						
					</td>
				</tr>
				<tr>
					<td><b>Enter Name</b></td>
					<td><?= form_input(['name'=>'name','placeholder'=>'Enter Name','class'=>'form-control']); ?>
						
					</td>
					<td><b>Enter Address</b></td>
					<td><?= form_input(['name'=>'address','placeholder'=>'Enter Address','class'=>'form-control']); ?>
						
					</td>
				</tr>
				<tr>
					<td><b>Enter City</b></td>
					<td><?= form_input(['name'=>' city','placeholder'=>'Enter City','class'=>'form-control']); ?>
					<td><b>Enter Mobile No</b></td>
					<td><?= form_input(['name'=>'mno','placeholder'=>'Enter Mobile Number','class'=>'form-control']); ?>
						
					</td>
				</tr>
				<tr>
					<td><?= form_submit(['name'=>'sub','value'=>'Book Now','class'=>'btn btn-primary']) ?></td>
				</tr>
			</table>
		</div>
	</div>
	<div class="container-fluid" style="background: darkred; color: white;">
		<h2 align="center">Copyright@engineersworld.com</h2>
	</div>
</body>
</html>