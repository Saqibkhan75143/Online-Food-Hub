<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE-edge" />
	<meta name="viewport" content="width=device-width" />
	<meta http-equiv="content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/style.css'); ?>">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
	<script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
</head>
<body>
<div class="container-fluid" style="background: darkred; color: white;">
    <?php include('admin_header.php'); ?>
	</div>
	<div class="container-fluid" id="banner"><br><br><br><br><br><br>
		<div class="col-sm-6" style="background: silver; margin-left: 20%;">
            <?php $un=$this->session->userdata('uid'); ?>
			<?= form_open('Admin_home/product_insert'); ?>
			 <h1>Product Insert</h1>
			 <table class="table">
			 	<tr>
					<td>Enter Product Name</td>
					<td><?= form_input(['type'=>'text','name'=>'name','placeholder'=>'Enter Product','class'=>'form-control']); ?></td>
				</tr>
				<tr>
					<td>Enter Product Price</td>
					<td><?= form_input(['type'=>'text','name'=>'price','placeholder'=>'Enter Price','class'=>'form-control']); ?></td>
				</tr>
				<tr>
					<td><?php echo form_submit(['name'=>'submit','value'=>'save','class'=>'btn btn-primary']); ?></td>
					<td>
						<?php
						if(isset($msg))
						{
							echo "Product Insert";
						}
						else
						{
							echo "Product Not Insert";
						}

						?>
					</td>
				</tr>
			 </table>
		</div>
	</div>
	<div class="container-fluid" style="background: darkred; color: white;">
		<h2 align="center">Copyright@engineersworld.com</h2>
	</div>
</body>
</html>