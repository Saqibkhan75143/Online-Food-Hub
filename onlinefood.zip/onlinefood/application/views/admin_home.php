<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE-edge" />
	<meta name="viewport" content="width=device-width" />
	<meta http-equiv="content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/style.css'); ?>">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
	<script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
</head>
<body>
<div class="container-fluid" style="background: darkred; color: white;">
    <?php include('admin_header.php'); ?>
	</div>
	<div class="container-fluid" id="banner"><br><br><br><br><br><br><br><br><br>
		<div class="col-sm-6" style="background: silver; margin-left: 20%;"><br>
            <?= $un=$this->session->userdata('uid'); ?>
			<?= form_open('admin_login/login') ?>
			<center><table class="table">
				<tr>
					<td>Enter Username</td>
					<td><?= form_input(['type'=>'text','name'=>'un','placeholder'=>'Enter Username','class'=>'form-control','value'=> set_value('un')]); ?></td>
					<td><?= form_error('un'); ?></td>
				</tr>
				<tr>
					<td>Enter Password</td>
					<td><?= form_input(['type'=>'password','name'=>'ps','placeholder'=>'Enter Password','class'=>'form-control','value'=> set_value('ps')]); ?></td>
					<td><?= form_error('ps'); ?></td>
				<tr>
					<td><?= form_submit(['name'=>'sub','value'=>'Login','class'=>'btn btn-primary']); ?></td>
				</tr>
			</table></center>
		</div>
	</div>
	<div class="container-fluid" style="background: darkred; color: white;">
		<h2 align="center">Copyright@engineersworld.com</h2>
	</div>
</body>
</html>