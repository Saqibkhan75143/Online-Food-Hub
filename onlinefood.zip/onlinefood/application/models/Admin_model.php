<?php 
/**
 * 
 */
class Admin_model extends CI_Model
{
    function insert_product($data)
    {
       return $this->db->insert('product',$data);
    }

    function select_data()
    {
     $query = $this->db->select(['id','name','price'])
    	         ->from('product')
    	         ->get();
    	return $query->result();
    }

    function sproduct($pname)
    {
    	$query = $this->db->select(['id','name','price'])
    	                  ->from('product')
    	                  ->where('name',$pname)
    	                  ->get();
    	    return $query->row();
    }

    function pbook($id)
    {
    	$query = $this->db->select(['id','name','price'])
    	                  ->from('product')
    	                  ->where('id',$id)
    	                  ->get();
    	    return $query->row();
    }

    function book2($data)
    {
    	return $this->db->insert('ofline_order',$data);
    }

    function ofline_order_disp()
    {
    	$query = $this->db->select(['cname','address','mobileno','pin','city','email','pname','price'])
    	                  ->from('ofline_order')
    	                  ->get();
    	    return $query->result();
    }

    function online_pro_disp()
    {
        $query = $this->db->get('online_order');
            return $query->result();
    }
}


?>