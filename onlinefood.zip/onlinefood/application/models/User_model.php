<?php 
/**
 * 
 */
class User_model extends CI_Model
{
	function ps($data)
	{
		$query = $this->db->select(['id','name','price'])
		                  ->from('product')
		                  ->where('name',$data)
		                  ->get();
		    return $query->result();
	}

	function ps1($data)
	{
		$query = $this->db->select(['id','name','price'])
		                  ->from('product')
		                  ->where('id',$data)
		                  ->get();
		    return $query->row();
	}

	function book_final($data)
	{
        return $this->db->insert('online_order',$data);
	}
}



?>