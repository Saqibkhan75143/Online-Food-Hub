<?php 
/**
 * 
 */
class Admin_loginn extends CI_Model 
{
	function login($un,$ps)
	{
       $q = $this->db->select(['un','ps'])
                       ->from('admin')
                      ->where(['un' => $un , 'ps' => $ps])
                      ->get();
        return $q->row();
	}
}


?>